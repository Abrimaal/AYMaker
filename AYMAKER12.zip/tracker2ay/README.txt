tracker2ay
==========
by Matt Westcott <matt@west.co.tt>

Converts Spectrum tracker files (.stc, .sqt, .pt3) to Spectrum native-code
formats (.tap, .tzx, .ay). Usage:

tracker2ay something.stc something.tap


Homepage / general file dump: http://matt.west.co.tt/files/tracker2ay/

                                           - Matt Westcott 2008-05-10
